def view_task(task):
    print('Title is: ', task['title'])
    print('Description is: ', task['description'])
    print('Deadline is: ', task['deadline'],'\n')

   























